# Perform timing tests

